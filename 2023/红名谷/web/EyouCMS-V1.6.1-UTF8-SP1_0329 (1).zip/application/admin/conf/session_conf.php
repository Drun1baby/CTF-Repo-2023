<?php
$session_1600593464 = json_encode(array (
  'expire' => '3600',
));
define('EY_SESSION_CONF', $session_1600593464);