<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022/4/19
 * Time: 14:15
 */

namespace app\admin\model;

use think\Model;

class ConfigType extends Model
{
    //初始化
    protected function initialize()
    {
        // 需要调用`Model`的`initialize`方法
        parent::initialize();
    }
}