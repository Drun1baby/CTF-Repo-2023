java -Xmx512M -Xms256M -jar paper-1.19.4-492-with-d3craft-patch.jar nogui
