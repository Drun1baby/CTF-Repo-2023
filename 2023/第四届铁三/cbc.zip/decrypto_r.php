<?php

if(isset($_GET['username'])&&isset($_GET['password']))
	$cipher = @encrypt($token);

if(isset($_GET['base64_cipher']))
	$c1 = @decrypt(base64_decode($_GET['base64_cipher']));
	if($user === 'admin')
        {
                echo $flag;
        }

define('MY_AES_KEY', "abcdef0123456789");
function aes($data, $encrypt) {
    $aes = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
    $iv = "1234567891234567";
    mcrypt_generic_init($aes, MY_AES_KEY, $iv);
    return $encrypt ? mcrypt_generic($aes,$data) : mdecrypt_generic($aes,$data);
}

define('MY_MAC_LEN', 40);

function encrypt($data) {
    return aes($data, true);
}

function decrypt($data) {
    $data = rtrim(aes($data, false), "\0");
    return $data;
}

